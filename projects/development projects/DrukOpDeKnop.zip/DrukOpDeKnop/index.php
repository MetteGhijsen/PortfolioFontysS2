<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>Mette's Javascript Speelplaats</title>
</head>
<body>
<button class="buttons" id="button" type="button">Haha klik eens</button>
<!--<button class="buttons" id="knop" type="button">Hover over mij</button>-->
<script src="js/scriptje.js"></script>
</body>
</html>